Sarrvesh S. Sridhar sarrvesh@student.chalmers.se

NED has 3 different entries for WENSS and all 3 entries have very different integrated flux at 92 cm. So, I have not included the WENSS flux in flux.dat
