Sarrvesh S. Sridhar sarrvesh@student.chalmers.se

There are quite a lot of different integrated flux values at 1.4 GHz using the VLA. Not sure which one to use in flux.dat. At the moment, I have included all the values listed in NED
