Sarrvesh S. Sridhar sarrvesh@student.chalmers.se

Hi-freq spectrum does not look good in spectra.eps. I guess it is due to bad/few data points. Will be on the look out for more data in the literature.
